(() => {
  'use strict';

  const KEY = 'mozakera.notes.v1';
  const THEME_KEY = 'mozakera.theme';
  const COLORS = ['none', 'red', 'orange', 'yellow', 'green', 'blue', 'purple'];
  const COLOR_HEX = {
    none: '#ffffff', red: '#fde4e1', orange: '#fdebd3', yellow: '#fbf3c8',
    green: '#dcf3df', blue: '#dbeafb', purple: '#ebe0fa'
  };

  const $ = (id) => document.getElementById(id);
  const el = {
    listView: $('listView'), editView: $('editView'), grid: $('notesGrid'), empty: $('empty'),
    search: $('search'), tagsBar: $('tagsBar'), fab: $('fab'),
    themeBtn: $('themeBtn'), menuBtn: $('menuBtn'), menu: $('menu'), importFile: $('importFile'),
    backBtn: $('backBtn'), pinBtn: $('pinBtn'), shareBtn: $('shareBtn'), delBtn: $('delBtn'),
    saveState: $('saveState'), titleInput: $('titleInput'), bodyInput: $('bodyInput'),
    colorPicker: $('colorPicker'), tagInput: $('tagInput'), meta: $('meta'), toast: $('toast')
  };

  /* ---------- التخزين ---------- */
  let notes = load();
  let state = { query: '', tag: null, trash: false, currentId: null };

  function load() {
    try {
      const data = JSON.parse(localStorage.getItem(KEY) || '[]');
      return Array.isArray(data) ? data : [];
    } catch { return []; }
  }
  function persist() {
    try { localStorage.setItem(KEY, JSON.stringify(notes)); return true; }
    catch { toast('تعذّر الحفظ: المساحة ممتلئة'); return false; }
  }
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const now = () => Date.now();

  /* ---------- أدوات ---------- */
  const fmtDate = (t) => new Date(t).toLocaleDateString('ar-EG', { day: 'numeric', month: 'short', year: 'numeric' });
  const fmtTime = (t) => new Date(t).toLocaleString('ar-EG', { dateStyle: 'medium', timeStyle: 'short' });
  const norm = (s) => (s || '').toLowerCase()
    .replace(/[ً-ٰٟ]/g, '')       // التشكيل
    .replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه');

  function parseTags(str) {
    return [...new Set(str.split(/[,،#\n]/).map(s => s.trim()).filter(Boolean))].slice(0, 10);
  }

  let toastTimer;
  function toast(msg, actionLabel, action) {
    el.toast.textContent = msg;
    if (actionLabel) {
      const b = document.createElement('button');
      b.textContent = actionLabel;
      b.onclick = () => { action(); el.toast.hidden = true; };
      el.toast.appendChild(b);
    }
    el.toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.toast.hidden = true; }, actionLabel ? 5000 : 2200);
  }

  /* ---------- القائمة الرئيسية ---------- */
  function visibleNotes() {
    const q = norm(state.query.trim());
    return notes
      .filter(n => !!n.deleted === state.trash)
      .filter(n => !state.tag || (n.tags || []).includes(state.tag))
      .filter(n => !q || norm(n.title).includes(q) || norm(n.body).includes(q) || (n.tags || []).some(t => norm(t).includes(q)))
      .sort((a, b) => (b.pinned - a.pinned) || (b.updated - a.updated));
  }

  function renderTags() {
    const all = new Set();
    notes.filter(n => !!n.deleted === state.trash).forEach(n => (n.tags || []).forEach(t => all.add(t)));
    el.tagsBar.innerHTML = '';
    if (!all.size) return;
    const mk = (label, tag) => {
      const b = document.createElement('button');
      b.className = 'chip' + (state.tag === tag ? ' active' : '');
      b.textContent = label;
      b.onclick = () => { state.tag = tag; render(); };
      el.tagsBar.appendChild(b);
    };
    mk('الكل', null);
    [...all].sort().forEach(t => mk('#' + t, t));
  }

  function render() {
    if (state.tag && !notes.some(n => (n.tags || []).includes(state.tag) && !!n.deleted === state.trash)) state.tag = null;
    renderTags();
    const list = visibleNotes();
    el.grid.innerHTML = '';
    el.empty.hidden = list.length > 0;
    el.empty.querySelector('p').textContent = state.trash ? 'سلة المحذوفات فارغة'
      : (state.query || state.tag) ? 'لا توجد نتائج مطابقة' : 'لا توجد ملاحظات بعد';
    el.empty.querySelector('small').hidden = state.trash || !!(state.query || state.tag);
    el.fab.hidden = state.trash;
    document.querySelector('#listView h1').textContent = state.trash ? 'سلة المحذوفات' : 'مذكرتي';

    for (const n of list) {
      const card = document.createElement('article');
      card.className = 'card';
      card.dataset.color = n.color || 'none';
      if (n.pinned) { const p = document.createElement('span'); p.className = 'pin'; p.textContent = '📌'; card.appendChild(p); }
      if (n.title) { const h = document.createElement('h3'); h.textContent = n.title; card.appendChild(h); }
      if (n.body) { const p = document.createElement('p'); p.textContent = n.body; card.appendChild(p); }
      if ((n.tags || []).length) {
        const t = document.createElement('div'); t.className = 'tags';
        n.tags.forEach(x => { const s = document.createElement('span'); s.className = 'tag'; s.textContent = '#' + x; t.appendChild(s); });
        card.appendChild(t);
      }
      const d = document.createElement('span'); d.className = 'date'; d.textContent = fmtDate(n.updated); card.appendChild(d);
      card.onclick = () => state.trash ? trashActions(n) : openEditor(n.id);
      el.grid.appendChild(card);
    }
  }

  function trashActions(n) {
    if (confirm('استعادة هذه الملاحظة؟\n(إلغاء = حذف نهائي)')) {
      n.deleted = null; n.updated = now(); persist(); render(); toast('تمت الاستعادة');
    } else if (confirm('حذف نهائي ولا يمكن التراجع؟')) {
      notes = notes.filter(x => x.id !== n.id); persist(); render();
    }
  }

  /* ---------- المحرر ---------- */
  let saveTimer = null;
  let dirty = false;

  function current() { return notes.find(n => n.id === state.currentId); }

  function openEditor(id) {
    const n = notes.find(x => x.id === id);
    if (!n) return;
    state.currentId = id;
    el.titleInput.value = n.title || '';
    el.bodyInput.value = n.body || '';
    el.tagInput.value = (n.tags || []).join('، ');
    applyEditorLook(n);
    el.saveState.textContent = '';
    el.listView.hidden = true;
    el.editView.hidden = false;
    history.pushState({ edit: true }, '');
    if (!n.title && !n.body) el.titleInput.focus();
  }

  function applyEditorLook(n) {
    el.editView.dataset.color = n.color || 'none';
    el.pinBtn.classList.toggle('on', !!n.pinned);
    el.meta.textContent = 'آخر تعديل: ' + fmtTime(n.updated) + ' • ' + (n.body || '').length + ' حرف';
    [...el.colorPicker.children].forEach(b => b.classList.toggle('sel', b.dataset.c === (n.color || 'none')));
  }

  function scheduleSave() {
    dirty = true;
    el.saveState.textContent = 'جارٍ الحفظ…';
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveNow, 500);
  }

  function saveNow() {
    clearTimeout(saveTimer);
    const n = current();
    if (!n || !dirty) return;
    n.title = el.titleInput.value.trim();
    n.body = el.bodyInput.value;
    n.tags = parseTags(el.tagInput.value);
    n.updated = now();
    dirty = false;
    if (persist()) el.saveState.textContent = 'تم الحفظ ✓';
    applyEditorLook(n);
  }

  function closeEditor() {
    saveNow();
    const n = current();
    // حذف الملاحظة الفارغة تلقائياً
    if (n && !n.title && !n.body) notes = notes.filter(x => x.id !== n.id), persist();
    state.currentId = null;
    el.editView.hidden = true;
    el.listView.hidden = false;
    render();
  }

  function newNote() {
    const n = { id: uid(), title: '', body: '', tags: [], color: 'none', pinned: false, created: now(), updated: now(), deleted: null };
    if (state.tag) n.tags = [state.tag];
    notes.unshift(n);
    openEditor(n.id);
  }

  /* ---------- أحداث ---------- */
  el.fab.onclick = newNote;
  el.search.oninput = () => { state.query = el.search.value; render(); };
  el.backBtn.onclick = () => history.back();
  window.addEventListener('popstate', () => { if (!el.editView.hidden) closeEditor(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) saveNow(); });
  window.addEventListener('pagehide', saveNow);

  [el.titleInput, el.bodyInput, el.tagInput].forEach(i => i.addEventListener('input', scheduleSave));

  COLORS.forEach(c => {
    const b = document.createElement('button');
    b.className = 'dot'; b.dataset.c = c; b.style.background = COLOR_HEX[c];
    b.setAttribute('aria-label', 'لون ' + c);
    b.onclick = () => { const n = current(); if (!n) return; n.color = c; dirty = true; saveNow(); };
    el.colorPicker.appendChild(b);
  });

  el.pinBtn.onclick = () => {
    const n = current(); if (!n) return;
    n.pinned = !n.pinned; dirty = true; saveNow();
    toast(n.pinned ? 'تم تثبيت الملاحظة' : 'تم إلغاء التثبيت');
  };

  el.shareBtn.onclick = async () => {
    saveNow();
    const n = current(); if (!n) return;
    const text = (n.title ? n.title + '\n\n' : '') + n.body;
    try {
      if (navigator.share) await navigator.share({ title: n.title || 'ملاحظة', text });
      else { await navigator.clipboard.writeText(text); toast('تم نسخ النص'); }
    } catch { /* ألغى المستخدم المشاركة */ }
  };

  el.delBtn.onclick = () => {
    const n = current(); if (!n) return;
    n.deleted = now(); dirty = false; persist();
    const id = n.id;
    history.back();
    toast('نُقلت الملاحظة إلى السلة', 'تراجع', () => {
      const x = notes.find(y => y.id === id);
      if (x) { x.deleted = null; persist(); render(); }
    });
  };

  /* القائمة */
  el.menuBtn.onclick = (e) => { e.stopPropagation(); el.menu.hidden = !el.menu.hidden; };
  document.addEventListener('click', () => { el.menu.hidden = true; });
  el.menu.onclick = (e) => {
    const act = e.target.dataset.act;
    if (!act) return;
    el.menu.hidden = true;
    if (act === 'export') exportData();
    if (act === 'import') el.importFile.click();
    if (act === 'trash') { state.trash = true; state.tag = null; render(); }
    if (act === 'active') { state.trash = false; state.tag = null; render(); }
  };

  function exportData() {
    const blob = new Blob([JSON.stringify({ app: 'mozakera', version: 1, exported: now(), notes }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'mozakera-backup-' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    toast('تم تصدير النسخة الاحتياطية');
  }

  el.importFile.onchange = async () => {
    const f = el.importFile.files[0]; el.importFile.value = '';
    if (!f) return;
    try {
      const data = JSON.parse(await f.text());
      const incoming = Array.isArray(data) ? data : data.notes;
      if (!Array.isArray(incoming)) throw 0;
      const ids = new Set(notes.map(n => n.id));
      let added = 0;
      for (const n of incoming) {
        if (!n || typeof n !== 'object' || ids.has(n.id)) continue;
        notes.push({
          id: String(n.id || uid()), title: String(n.title || ''), body: String(n.body || ''),
          tags: Array.isArray(n.tags) ? n.tags.map(String).slice(0, 10) : [],
          color: COLORS.includes(n.color) ? n.color : 'none', pinned: !!n.pinned,
          created: +n.created || now(), updated: +n.updated || now(), deleted: n.deleted ? +n.deleted : null
        });
        added++;
      }
      persist(); render(); toast('تم استيراد ' + added + ' ملاحظة');
    } catch { toast('ملف غير صالح'); }
  };

  /* الوضع الداكن */
  function applyTheme(t) {
    document.documentElement.dataset.theme = t;
    const m = document.querySelector('meta[name="theme-color"]');
    if (m) m.content = t === 'dark' ? '#12151c' : '#0f766e';
  }
  const saved = (() => { try { return localStorage.getItem(THEME_KEY); } catch { return null; } })();
  applyTheme(saved || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
  el.themeBtn.onclick = () => {
    const t = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    applyTheme(t);
    try { localStorage.setItem(THEME_KEY, t); } catch {}
  };

  /* PWA: العمل بدون إنترنت */
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }

  render();
})();
